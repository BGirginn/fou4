# FOU4 Quick Start Guide

Get up and running with FOU4 in 5 minutes!

---

## 🚀 Installation (3 minutes)

### Step 1: Open Terminal

```bash
# Navigate to FOU4 directory
cd /path/to/fou4
```

### Step 2: Run Installer

```bash
# Make executable (if needed)
chmod +x install.sh

# Run installation
sudo ./install.sh
```

**What happens:**
- Checks Python 3.7+
- Installs dependencies (Rich library)
- Installs security tools (nmap, gobuster, dirb, etc.)
- Sets up `fou4` command
- Takes ~3-5 minutes

### Step 3: Verify

```bash
# Test installation
sudo fou4

# You should see the FOU4 banner!
```

---

## 🎯 First Use (2 minutes)

### Step 1: Start FOU4

```bash
sudo fou4
```

### Step 2: Create Workspace

```
Main Menu → [9] Workspace → [1] Create new workspace

Name: MyFirstScan
Description: Test scanning
Target: 192.168.1.0/24

✓ Workspace created!
```

### Step 3: Run Your First Scan

**Option A: Network Scan**
```
Main Menu → [2] Network Module → [1] Nmap Quick Scan

Target: 192.168.1.1
→ Scan runs
→ View results
```

**Option B: Web Scan**
```
Main Menu → [3] Web Module → [1] Gobuster

URL: http://testphp.vulnweb.com
Wordlist: /usr/share/wordlists/dirb/common.txt
→ Scan runs
→ View findings
```

**Option C: OSINT**
```
Main Menu → [4] OSINT Module

Domain: example.com
Sources: all
→ Gather intelligence
→ View results
```

### Step 4: Generate Report

```
Main Menu → [5] Reporting

→ View statistics
→ Press Y to generate
→ report-MyFirstScan-YYYYMMDD.md created
```

---

## 📝 Common Commands

```bash
# Start FOU4
sudo fou4

# Run from source
sudo python3 fou4.py

# Verify installation
python3 verify_installation.py

# Uninstall
sudo ./uninstall.sh
```

---

## 🎓 Learning Path

### Beginner

1. ✅ Install FOU4
2. ✅ Create workspace
3. ✅ Run network scan
4. ✅ Generate report

### Intermediate

1. Use multiple modules
2. Chain scans (network → web)
3. Customize wordlists
4. Manage multiple workspaces

### Advanced

1. Integrate with custom tools
2. Automate workflows
3. Export data to other tools
4. Contribute to development

---

## 💡 Tips

**Tip 1: Use Workspaces**
- Create separate workspace for each project
- Switch between projects easily
- Keep data organized

**Tip 2: Let Smart Automation Help**
- After network scans, FOU4 suggests web scans
- Automatically detects web ports (80, 443, etc.)
- Just press Y to continue

**Tip 3: Save Everything**
- All scan results saved to database (fou4.db)
- Generate reports anytime
- Query old scans later

**Tip 4: Install Tools On-Demand**
- Don't have a tool? FOU4 will offer to install it
- Just confirm with Y
- Continues automatically

---

## 🆘 Quick Help

### Problem: "Permission denied"
**Solution**: Use `sudo`
```bash
sudo fou4
```

### Problem: "Tool not found"
**Solution**: Install it
```bash
sudo apt-get install <tool-name>
```

### Problem: "Module import error"
**Solution**: Reinstall dependencies
```bash
pip3 install -r requirements.txt
```

### Problem: "Database locked"
**Solution**: Kill other instances
```bash
pkill -f fou4
rm -f fou4.db-journal
```

---

## 📚 Full Documentation

- **[README.md](README.md)** - Complete documentation
- **[INSTALL.md](INSTALL.md)** - Detailed installation guide
- **[CONTRIBUTING.md](CONTRIBUTING.md)** - How to contribute
- **[CHANGELOG.md](CHANGELOG.md)** - Version history

---

## 🎉 You're Ready!

```bash
# Start scanning now!
sudo fou4
```

**Next Steps:**
1. Try all 5 modules
2. Create multiple workspaces
3. Generate professional reports
4. Explore advanced features

**Happy hacking! 🔍**

---

<div align="center">

**Questions?** Check [README.md](README.md) or report issues on GitHub

**Quick Command**: `sudo ./install.sh && sudo fou4`

</div>
